# This is my Package Assignment
Packaging the Banking Systems
1. It is a very basic banking system with several features:
   a. Deposits
   b. Withdrawals
   c. Check Balances in Savings or Checking Account 
   d. Transfers between Accounts
2. It contains 5 functions not including Main()
   a. deposit()
   b. withdraw_funds()
   c. show_balance()
   d. transfer()
   e. show_account_balance()